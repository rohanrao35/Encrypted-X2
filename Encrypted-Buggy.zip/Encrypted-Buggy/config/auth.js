module.exports = {
	'googleAuth' : {
		'clientID': '710056015402-fp3tor41ct7av3bvggee93n6kk5gn5q4.apps.googleusercontent.com',
		'clientSecret': 'U9h05HoeKby3lCdgvZPw-e1r',
		'callbackURL': "http://localhost:3000/auth/google/callback"
	}
}
